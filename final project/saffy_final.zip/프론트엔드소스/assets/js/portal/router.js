

const router = new VueRouter({
    mode: "history",
    routes: [
        { path: '/', component: LoginComponent },
        
      ]
})