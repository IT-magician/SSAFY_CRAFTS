<template>
  <div class="app-content">
    
    <div class="section app-content-window">a</div>
    <div id="map"></div>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>