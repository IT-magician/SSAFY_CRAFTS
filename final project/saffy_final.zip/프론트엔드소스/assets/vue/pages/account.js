export default {
  template: `
  
  
<div>
  <div class="bg"></div>
  <div class="bg"></div>
  <div class="bg"></div>



  <router-view></router-view>
</div>
  `,
};
