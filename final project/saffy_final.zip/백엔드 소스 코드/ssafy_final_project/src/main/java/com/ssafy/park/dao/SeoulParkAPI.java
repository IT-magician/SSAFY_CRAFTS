package com.ssafy.park.dao;

public class SeoulParkAPI {

}
