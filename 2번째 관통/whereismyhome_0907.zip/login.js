window.onload = localStorageInit;

function localStorageInit() {
    // 회원 정보를 저장하는 배열
    const userInfos = JSON.parse(localStorage.getItem("userInfos"));
    if (!userInfos) {
        localStorage.setItem("userInfos", JSON.stringify([{id : "admin", password : "admin", name : "admin"}, 
        {id : "admin1", password : "admin1", name : "admin1"}]));
    }
}

function regist() {
    const userInfos = JSON.parse(localStorage.getItem("userInfos"));

    const id = document.querySelector("#ID_BOX2").value;
    const password = document.querySelector("#PASSWD_BOX2").value;
    const name = document.querySelector("#NAME_BOX2").value;

    if (!id || !password || !name) {
        alert("빈 칸이 없도록 입력해주세요.");
        return;
    } else {
        const user = {
            id: id,
            password: password,
            name: name
        };

        const foundUser = userInfos.find(userInfo => {
            return userInfo.id === id;
        });

        // 같은 아이디의 회원이 존재하는 경우
        if (foundUser) {
            alert("이미 가입된 아이디입니다.");
            return;
        } else {
            // 회원 정보 삽입
            userInfos.push(user);
            localStorage.setItem("userInfos", JSON.stringify(userInfos));
            alert("회원가입 성공");
            //로그인으로 flip
            document.querySelector("#flip").checked = false;
        }
    }
}

function login() {
    const userInfos = JSON.parse(localStorage.getItem("userInfos"));

    let id = document.querySelector("#ID_BOX1").value;
    let password = document.querySelector("#PASSWD_BOX1").value;

    const foundUser = userInfos.find(userInfo => {
        return userInfo.id === id && userInfo.password === password;
    });

    if (foundUser) {
        alert("로그인 성공");
        sessionStorage.setItem("isLogIn", "True");
        sessionStorage.setItem("loginId", id);
        window.location.replace(window.location.protocol + "//" + "localhost:" + window.location.port + "/index.html");
    } else {
        alert("등록되지 않은 회원입니다. 회원가입을 진행 해 주세요");
        //SignUp 쪽으로 Flip
    }
}