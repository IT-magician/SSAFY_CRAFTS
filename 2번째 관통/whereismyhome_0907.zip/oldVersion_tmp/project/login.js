function regist() {
    let id = document.querySelector("#ID_BOX2").value
    let password = document.querySelector("#PASSWD_BOX2").value
    let name = document.querySelector("#NAME_BOX2").value
    

    if (!id || !password || !name) {
        alert("빈 칸이 없도록 입력해주세요.")
        return
    } else {
        const user = {
            ID_BOX2: id,
            PASSWD_BOX2: password,
            NAME_BOX2: name
        };

        localStorage.setItem("user", JSON.stringify(user))
        alert("회원가입 성공")
        document.querySelector("#flip").checked = false;
        //로그인으로 flip
    }
}

function login() {
    let id = document.querySelector("#ID_BOX1").value
    let password = document.querySelector("#PASSWD_BOX1").value

    const user = JSON.parse(localStorage.getItem("user"))
    console.log(id)
    if (user.ID_BOX2 && user.PASSWD_BOX2 && user.ID_BOX2 === id && user.PASSWD_BOX2 === password) {
        alert("로그인 성공")
        sessionStorage.setItem("isLogIn","True")
        window.location.replace("./index.html")
    } else {
        alert("등록되지 않은 회원입니다. 회원가입을 진행 해 주세요")
        //SignUp 쪽으로 Flip
    }
}
