const getAPTList = async (lawdCD, dealYmd) => {
    const serviceKey = "NjkyyeC50eAnaMhx3HqSP4OVYwNfYzzlp0NKpUSSPR6GMLQFVAmsdMkNKqU2nYl1uOGh3kr23mHoe87gR1hqtw%3D%3D";
    const url = `http://openapi.molit.go.kr/OpenAPI_ToolInstallPackage/service/rest/RTMSOBJSvc/getRTMSDataSvcAptTradeDev?LAWD_CD=${lawdCD}&DEAL_YMD=${dealYmd}&serviceKey=${serviceKey}`;

    const data = [];
    await fetch(url).then(response => response.text()).then(result => {
        const parser = new DOMParser();
        const xml = parser.parseFromString(result, "application/xml");
        xml.querySelectorAll("item").forEach(item => {
            data.push(createApartDealDetail(item));
        });
    })
        .catch(console.error);
    
    console.log(data)
    
    return data;
}

const createApartDealDetail = (item) => {
    return {
        dealPrice: getContent(item, "거래금액") + "원",
        buildAt: getContent(item, "건축년도"),
        dealYear: getContent(item, "년"),
        roadName: getContent(item, "도로명"),
        village: getContent(item, "법정동"),
        apartName: getContent(item, "아파트"),
        dealMonth: getContent(item, "월"),
        dealDay: getContent(item, "일"),
        area: getContent(item, "전용면적"),
        floor: getContent(item, "층"),
    }
}

const getContent = (item, tagName) => {
    return item.querySelector(tagName).textContent.trim()
}
